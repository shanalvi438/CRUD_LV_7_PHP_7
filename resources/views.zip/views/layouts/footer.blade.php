<!-- Footer Start -->
<div class="flex-grow-1"></div>
<div class="app-footer">
    <div class="footer-bottom border-top pt-3 d-flex flex-column flex-sm-row align-items-center">

        <span class="flex-grow-1"></span>
        <div class="d-flex align-items-center">
            <img class="logo" src="{{asset('public/images/logo.png')}}" style="border-radius: 3px; padding-right: 5px;">
            <div>
                <p class="m-0">&copy; 2021 Elite Home Healthcare</p>
                <p class="m-0">All rights reserved</p>
            </div>
        </div>
    </div>
</div>
<!-- fotter end -->
<script>
    var base_url = '{{ url('/') }}';
</script>
