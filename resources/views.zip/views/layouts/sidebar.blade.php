<div class="side-content-wrap">
    <div class="sidebar-left open rtl-ps-none" data-perfect-scrollbar data-suppress-scroll-x="true">
        <ul class="navigation-left">
            <li class="nav-item {{ request()->is('home') ? 'active' : '' }}">
                <a class="nav-item-hold" href="{{url('/home')}}">
                    <i class="nav-icon i-Bar-Chart"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
                <div class="triangle"></div>
            </li>
            <li class="nav-item {{ request()->is('users*') ? 'active' : '' }}">
                <a class="nav-item-hold" href="{{route('users')}}">
                    <i class="nav-icon i-Conference"></i>
                    <span class="nav-text">Users</span>
                </a>
                <div class="triangle"></div>
            </li>
            <li class="nav-item {{ request()->is('categories*') ? 'active' : '' }}">
                <a class="nav-item-hold" href="{{route('categories')}}">
                    <i class="nav-icon i-Tag"></i>
                    <span class="nav-text">Categories</span>
                </a>
                <div class="triangle"></div>
            </li>
            <li class="nav-item {{ request()->is('posts*') ? 'active' : '' }}">
                <a class="nav-item-hold" href="{{route('posts')}}">
                    <i class="nav-icon i-Post-Mail"></i>
                    <span class="nav-text">Posts</span>
                </a>
                <div class="triangle"></div>
            </li>
            <li class="nav-item {{ request()->is('news*') ? 'active' : '' }}">
                <a class="nav-item-hold" href="{{route('news')}}">
                    <i class="nav-icon i-Newspaper-2"></i>
                    <span class="nav-text">News</span>
                </a>
                <div class="triangle"></div>
            </li>
            <li class="nav-item {{ request()->is('content-management*') ? 'active' : '' }}">
                <a class="nav-item-hold" href="{{route('cms')}}">
                    <i class="nav-icon i-Gear-2"></i>
                    <span class="nav-text">Content Management</span>
                </a>
                <div class="triangle"></div>
            </li>
            <li class="nav-item {{ request()->is('treasure-chest*') ? 'active' : '' }}">
                <a class="nav-item-hold" href="{{route('treasure-chest')}}">
                    <i class="nav-icon i-Coins"></i>
                    <span class="nav-text">Treasure Chest</span>
                </a>
                <div class="triangle"></div>
            </li>
            <li class="nav-item {{ request()->is('notifications*') ? 'active' : '' }}">
                <a class="nav-item-hold" href="{{route('notification-create')}}">
                    <i class="nav-icon i-Support"></i>
                    <span class="nav-text">Notifications</span>
                </a>
                <div class="triangle"></div>
            </li>
            <li class="nav-item {{ request()->is('support*') ? 'active' : '' }}">
                <a class="nav-item-hold" href="{{url('support')}}">
                    <i class="nav-icon i-Support"></i>
                    <span class="nav-text">Support</span>
                </a>
                <div class="triangle"></div>
            </li>
        </ul>
    </div>

    <div class="sidebar-overlay"></div>
</div>
<!--=============== Left side End ================-->
