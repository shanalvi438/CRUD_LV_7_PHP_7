<div id="pageloader">
    <span class="spinner-glow spinner-glow-primary mr-5"></span>
</div>
